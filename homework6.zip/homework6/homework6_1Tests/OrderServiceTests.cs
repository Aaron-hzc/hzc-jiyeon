﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using homework6_1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework6_1.Tests
{
    [TestClass()]
    public class OrderServiceTests
    {
        [TestMethod()]
        public void AddOrderTest()
        {
            void AddOrderTest()
            {
                OrderService os1 = new OrderService();
                OrderService os2 = new OrderService();

                List<OrderDetails> od1 = new List<OrderDetails>();
                od1.Add(new OrderDetails("Aaron", 3, 10));
                od1.Add(new OrderDetails("Aaron", 4, 7));
                List<OrderDetails> od2 = new List<OrderDetails>();
                od2.Add(new OrderDetails("Aaron", 2, 9));
                od2.Add(new OrderDetails("Aaron", 1, 10));

                Order a = new Order("Aaron", od1);
                Order b = new Order("Aaron", od2);

                os1.Orders.Add(a);
                os1.Orders.Add(b);
                os2.Orders.Add(a);
                Dictionary<Commodity, int> _a = new Dictionary<Commodity, int>();
                bool result = os2.AddOrder("Aaron", _a);
            }
        }

        [TestMethod()]
        void ChangeOrderTest()
        {
            List<OrderDetails> a1 = new List<OrderDetails>();
            List<OrderDetails> a2 = new List<OrderDetails>();
            List<OrderDetails> a3 = new List<OrderDetails>();

            a1.Add(new OrderDetails("a", 1, 10));
            a1.Add(new OrderDetails("a", 2, 10));
            a2.Add(new OrderDetails("b", 3, 10));
            a2.Add(new OrderDetails("b", 1, 10));
            a3.Add(new OrderDetails("c", 2, 10));
            a3.Add(new OrderDetails("c", 3, 10));

            Order _a1 = new Order("aaa", a1);
            Order _a2 = new Order("bbb", a2);
            Order _a3 = new Order("ccc", a3);

            OrderService a = new OrderService();
            a.Orders.Add(_a1);
            a.Orders.Add(_a2);

            a.ChangeOrder(_a1.ID, _a2.ID);

            Assert.IsTrue(a.Orders.Exists(o => o.ID == _a3.ID));//新订单取代并放入订单集合
            Assert.IsFalse(a.Orders.Exists(o => o.ID == _a1.ID));//删除原订单
        }

        [TestMethod()]
        public void DeleteOrderTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void IDFindTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void NameFindTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void OrderSortTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void SortOrderTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void ExportTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void ImportTest()
        {
            Assert.Fail();
        }
    }
}